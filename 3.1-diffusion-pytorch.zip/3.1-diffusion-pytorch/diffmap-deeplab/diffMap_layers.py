import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Function
import SpixelAggr_avr_cuda
import numpy as np
from diffMap_deeplab.diffMap_functional import  *

# Feat2Dist
class Feat2Dist(nn.Module):
    def __init__(self):
        super(Feat2Dist, self).__init__()

    def forward(self, input):
        return Feat2Dist_function.apply(input)


# super-pixel aggragation
class SpixelAggr_avr(nn.Module):
    def __init__(self):
        super(SpixelAggr_avr, self).__init__()
        #self.input_features = input_feature
        #self.segLabels = segLabels
        #self.coor_idx = coor_idx

    def forward(self, input, segLabels, coor_idx):
        #(input, segLabels, coor_idx) = inputs
        return SpixelsAggr_avr_function.apply(input, segLabels, coor_idx)


# super-pixel aggragation
class SpixelAggr_avr_dense(nn.Module):
    def __init__(self):
        super(SpixelAggr_avr_dense, self).__init__()
        #self.input_features = input_feature
        #self.segLabels = segLabels
        #self.coor_idx = coor_idx

    def forward(self, input, segLabels):
        #(input, segLabels, coor_idx) = inputs
        return SpixelsAggr_avr_dense_function.apply(input, segLabels)

# dist2SimiMatrix
class dist2SimiMatrix(nn.Module):
    def __init__(self, wei):
        super(dist2SimiMatrix, self).__init__()
        self.weights = nn.Parameter(torch.log(torch.Tensor(([wei]))).double())


    def forward(self, input):
        return dist2SimiMatrix_function.apply(input, self.weights)


# dist2SimiMatrix_scale
class dist2SimiMatrix_scale(nn.Module):
    def __init__(self):
        super(dist2SimiMatrix_scale, self).__init__()
        self.weights = nn.Parameter(torch.log(torch.Tensor([1e-3])).double())


    def forward(self, input):
        return dist2SimiMatrix_scale_function.apply(input, self.weights)


# neighMasking
class neighMasking(nn.Module):
    def __init__(self):
        super(neighMasking, self).__init__()
        #self.state_size = state_size
        #self.neigMask = neigMask

    def forward(self, input, neigMask):
        return neighMasking_function.apply(input, neigMask)


#compNormSimiMatrix
class compNormSimiMatrix(nn.Module):
    def __init__(self):
        super(compNormSimiMatrix, self).__init__()

    def forward(self, input):
        return compNormSimiMatrix_function.apply(input)


# compEigDecomp
class compEigDecomp(nn.Module):
    def __init__(self):
        super(compEigDecomp, self).__init__()

    def forward(self, input):
        return compEigDecomp_function.apply(input)


# compDiffDist
class compDiffDist(nn.Module):
    def __init__(self):
        super(compDiffDist, self).__init__()
        self.weights = nn.Parameter(torch.Tensor([8]).double())

    def forward(self, input_G, input_V):
        return compDiffDist_function.apply(input_G, input_V, self.weights)

# compLoss
class loss_kernelMatching(nn.Module):
    def __init__(self):
        super(loss_kernelMatching, self).__init__()

    def forward(self, pred, targ):
        return kernelMatching_function.apply(pred, targ)