import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Function
import SpixelAggr_avr_cuda
import numpy as np


# conf_diff
#class conf_diff_function(Function):
#    @staticmethod
#    def forward(ctx, input):
#        (x, W) = input
#        W =


#        return y


 #   def backward(ctx, dzdy):



#       return y

# Feat2Dist
class Feat2Dist_function(Function):
    @staticmethod
    def forward(ctx, input):
        imgx = input.squeeze().double()
        r, c = imgx.size()
        xnorm = imgx.pow(2).sum(1).reshape(r,1)
        vone = torch.ones(r, 1, dtype = torch.float64).cuda()
        y = (vone.mm(xnorm.transpose(1,0)) + xnorm.mm(vone.transpose(1,0))) - 2 * imgx.mm(imgx.transpose(0,1))

        ctx.save_for_backward(input, vone)

        return y

    @staticmethod
    def backward(ctx, dzdy):
        imgx, vone = ctx.saved_variables
        imgx = imgx.double()
        y = 2 * (dzdy.mm(vone).view(-1).diag() + vone.transpose(1,0).mm(dzdy).view(-1).diag() - dzdy - dzdy.transpose(1,0)).mm(imgx)

        #import matplotlib.pyplot as plt
        #plt.imshow(dzdy)
        #plt.show()

        return y


class SpixelsAggr_avr_dense_function(Function):
    @staticmethod
    def forward(ctx, input, segLabels):

        #### Just for debug
        '''
        import scipy.io
        mat_file = scipy.io.loadmat('data_tmp.mat')
        input0 = mat_file['input']
        input0 = torch.from_numpy(np.asarray(input0, np.float64)).cuda().permute(2,0,1)
        input = torch.zeros(1, 128, input.size(2), input.size(3)).cuda().double()
        input[0,:,:40, :60] = input0
        ####
        '''

        segLabels = segLabels.squeeze()

        #'''
        r, d = segLabels.shape
        #range1 = torch.arange(r)
        #range0 = torch.arange(d)
        #idx = torch.arange(r*d) #range1 * d + range0

        labels_idx = segLabels.reshape(-1).double() #[idx]
        nSegs = torch.from_numpy(np.bincount(labels_idx)[1:].astype(np.float64)).cuda()  # , weights = a

        feat = input.squeeze().double() #input.size(2)-1-1

        ctx.save_for_backward(input, labels_idx, nSegs)
        output = torch.zeros(input.size(1), nSegs.size(0),  dtype=torch.float64).cuda()

        #print(output.size(), feat.size(), labels_idx.size(), nSegs.size())

        output = SpixelAggr_avr_cuda.forward(output.contiguous(), feat.contiguous(),
                                             labels_idx.contiguous(),
                                             nSegs.contiguous())


        return output[0].permute(1,0)

    @staticmethod
    def backward(ctx, grad_out):
        input, labels_idx, nSegs = ctx.saved_variables
        input = input.squeeze() #.permute((1, 2, 0))
        d, r, c = input.size()

        grad_in = torch.zeros(d, r-1, c-1).double().cuda() #-1
        grad = torch.zeros(1, d, r, c).double().cuda()
        grad_in = SpixelAggr_avr_cuda.backward(grad_in.contiguous(), grad_out.permute(1,0).contiguous(), labels_idx.contiguous(), nSegs.contiguous())

        #grad[0, :, :r-1, :c-1 ] = grad_in[0] #-1

        #print(grad_out[37, :40])
        #grad_in_tmp = grad_in[0].squeeze().reshape(2048, -1)
        #print(grad_in_tmp[:40, 1842])

        #print(grad[0, :20, 0, 0])

        return  grad_in.float(), None #,


# super-pixel aggragation
class SpixelsAggr_avr_function(Function):
    @staticmethod
    def forward(ctx, input, segLabels, coor_idx):

        #### Just for debug
        '''
        import scipy.io
        mat_file = scipy.io.loadmat('data_tmp.mat')
        input0 = mat_file['input']
        input0 = torch.from_numpy(np.asarray(input0, np.float64)).cuda().permute(2,0,1)
        input = torch.zeros(1, 128, input.size(2), input.size(3)).cuda().double()
        input[0,:,:40, :60] = input0
        ####
        '''

        segLabels = segLabels.squeeze()
        #'''
        r, d = segLabels.shape
        # idx = (coor_idx[0] - 1) * d + coor_idx[1] - 1
        six = coor_idx[0].cpu().unique().__len__()
        siy = coor_idx[1].cpu().unique().__len__()

        idx = ((coor_idx[1] - 1) * d + coor_idx[0] - 1).long()

        labels_idx = segLabels.reshape(-1)[idx].double()
        nSegs = torch.from_numpy(np.bincount(labels_idx)[1:].astype(np.float64)).cuda()  # , weights = a

        feat = input[:,:,0:siy, 0:six ].squeeze().double() #input.size(2)-1-1

        ctx.save_for_backward(input, labels_idx, nSegs)
        output = torch.zeros(input.size(1), nSegs.size(0),  dtype=torch.float64).cuda()

        #print(output.size(), feat.size(), labels_idx.size(), nSegs.size())

        output = SpixelAggr_avr_cuda.forward(output.contiguous(), feat.contiguous(),
                                             labels_idx.contiguous(),
                                             nSegs.contiguous())


        return output[0].permute(1,0)

    @staticmethod
    def backward(ctx, grad_out):
        input, labels_idx, nSegs = ctx.saved_variables
        input = input.squeeze() #.permute((1, 2, 0))
        d, r, c = input.size()

        grad_in = torch.zeros(d, r-1, c-1).double().cuda() #-1
        grad = torch.zeros(1, d, r, c).double().cuda()
        grad_in = SpixelAggr_avr_cuda.backward(grad_in.contiguous(), grad_out.permute(1,0).contiguous(), labels_idx.contiguous(), nSegs.contiguous())

        grad[0, :, :r-1, :c-1 ] = grad_in[0] #-1

        #print('debug')

        #print(grad_out[37, :40])
        #grad_in_tmp = grad_in[0].squeeze().reshape(2048, -1)
        #print(grad_in_tmp[:40, 1842])

        #print(grad[0, :20, 0, 0])

        return  grad.float(), None, None #,


# dist2SimiMatrix_scale
class dist2SimiMatrix_function(Function):
    @staticmethod
    def forward(ctx, input, weights):
        r,d = input.size()
        scale = weights
        scale_exp = torch.exp(scale)
        x = F.relu(input)
        y = torch.exp(-scale_exp * x)

        if (torch.isnan(x).sum() > 0):
            x = x

        ctx.save_for_backward(input, weights)

        return y

    @staticmethod
    def backward(ctx, dzdy):
        input, weights = ctx.saved_variables
        r, d = input.size()
        scale =  weights
        scale_exp = torch.exp(scale)

        #x = F.relu(input)
        x = input
        y = dzdy * torch.exp(-scale_exp * x) * (-scale_exp)
        dw = (dzdy * (-x) * torch.exp(-scale_exp * x) * scale_exp).sum().reshape(1)

        #print(scale_exp[0])

        if torch.isnan(y).sum() > 0:
            print('nan: dist2simi')
            print(torch.isnan(x).nonzero())
            print(scale_exp)


        #print(y[100, :10])

        return y, dw


# dist2SimiMatrix_scale
class dist2SimiMatrix_scale_function(Function):
    @staticmethod
    def forward(ctx, input, weights):
        ctx.save_for_backward(input, weights)
        r,d = input.size()
        scale = weights
        x = F.relu(input)
        ONE = torch.ones(r,1).cuda()
        xv = torch.sqrt(1 / (x * ONE)).diag()
        vx = torch.sqrt(1 / (ONE.transpose(1, 0) * x)).diag()
        y = torch.exp(-scale * xv.mm(x).mm(vx) * r)
        return y

    @staticmethod
    def backward(ctx, dzdy):
        input, weights = ctx.saved_variables
        r, d = input.size()
        scale = weights
        x = F.relu(input)
        ONE = torch.ones(r, 1)
        xv = torch.sqrt(1 / (x * ONE)).diag()
        vx = torch.sqrt(1 / (ONE.transpose(1, 0) * x)).diag()
        dzds = -scale * dzdy * r * dzdy
        y = -0.5 * (dzds * (xv.pow(3).mm(x).mm(vx)).mm(ONE).mm(ONE.transpose(0,1))) - 0.5 * ONE * ONE.transpose(1, 0).mm(dzds * (xv.mm(x).mm(vx.pow(3)))) + xv.mm(dzds.mm(vx))
        dw = (-dzdy * (xv.mm(x).mm(vx)) * r).sum()
        return y, dw


# neighMasking
class neighMasking_function(Function):
    @staticmethod
    def forward(ctx, input, neigW):
        neigW = neigW.squeeze()
        neigMask = neigW.mm(neigW).mm(neigW).mm(neigW).mm(neigW).mm(neigW)
        y = input * (((neigMask + neigMask.transpose(1,0)) > 0).double())
        ctx.save_for_backward(input, neigMask)
        return y

    @staticmethod
    def backward(ctx, dzdy):
        input, neigMask = ctx.saved_variables
        y = dzdy * ((neigMask + neigMask.transpose(1,0)) > 0).double()

        #import matplotlib.pyplot as plt
        #plt.imshow(y)
        #plt.show()

        return y, None


#compNormSimiMatrix
class compNormSimiMatrix_function(Function):
    @staticmethod
    def forward(ctx, input):
        r,d = input.size()
        #ONE = torch.ones(r, 1).cuda()
        simi = input.squeeze()
        EPS = torch.full((r,1), 1e-5, dtype=torch.float64).squeeze().cuda()
        D = 1 / torch.max(simi.sum(1), EPS)
        y = D.diag().mm(simi)
        ctx.save_for_backward(input, EPS, D)
        return y

    @staticmethod
    def backward(ctx, dzdy):
        input, EPS, D = ctx.saved_variables
        r, d = input.size()
        ONE = torch.ones(r, 1, dtype=torch.float64).cuda()
        simi = input.squeeze()

        #print(D.pow(2).diag().mm(simi).mm(dzdy.transpose(1,0)).diag().size())
        y = D.diag().mm(dzdy) - (D.pow(2).diag().mm(simi).mm(dzdy.transpose(1,0))).diag().reshape(-1, 1).mm(ONE.transpose(1,0))
        return y


# compEigDecomp
class compEigDecomp_function(Function):

    @staticmethod
    def forward(ctx, input):
        x = input.squeeze()
        r, d = x.size()

        G, V = torch.eig(x, eigenvectors=True)

        G = G[:, 0].view(-1)
        tmp, order = torch.sort(G, 0, descending=True)
        eigG = G[order].diag()
        eigV = V[:, order]
        ctx.save_for_backward(input, eigG.diag(), eigV)
        return eigG.diag(), eigV

    @staticmethod
    def backward(ctx, dzdG, dzdV):
        input, eigG, eigV = ctx.saved_variables


        dzdG = dzdG.diag()
        x = input.squeeze()
        r, d = x.size()
        n_neig = dzdG.size(1)
        vone = torch.ones(r, 1, dtype=torch.float64).cuda()

        if n_neig < r:
            dzdV = torch.cat((dzdV, torch.zeros(r, r - n_neig, dtype=torch.float64).cuda()), 1)
            dzdG = torch.cat((dzdG.diag().reshape(1,-1), torch.zeros(1, r-n_neig, dtype=torch.float64).cuda()), 1).view(-1).diag()

        #print(dzdG.size())
        #print(dzdV.size())

        eigG_d2 = eigG.reshape(-1,1)

        diff = eigG_d2.mm(vone.permute(1,0))-(eigG_d2.mm(vone.permute(1,0))).permute(1,0)

        K = 1 / diff
        K[torch.eye(K.size(0)) > 0] = 0

        K[torch.isnan(K)] = 0
        K[K == float("Inf")] = 0

        tmp = (eigV.permute(1, 0).mm(dzdV))
        y = eigV.mm(dzdG).mm(eigV.permute(1,0)) + eigV.mm(K.permute(1,0) * tmp).mm(eigV.permute(1,0))

        if torch.isnan(y).sum() > 0:
            print('nan: eig')

        #import matplotlib.pyplot as plt
        #plt.imshow(y)
        #plt.show()

        return y


# compDiffDist
class compDiffDist_function(Function):
    @staticmethod
    def forward(ctx, G, V, t):
        #G, V = input
        #Gs = G.diag()
        G = G.diag()
        r, d = V.size()
        n_eigs = min(100,d)
        st = 1
        G = torch.max(G, torch.zeros_like(G))
        E = torch.ones(r, n_eigs - st + 1, dtype = torch.float64).cuda()
        Phi = V[:, st-1: n_eigs]
        Phi2 = Phi.pow(2)
        eVs = ((G[st-1: n_eigs, st-1: n_eigs]).diag().pow(2 * t)).diag()
        y = E.mm(eVs).mm(Phi2.transpose(1,0)) + Phi2.mm(eVs).mm(E.transpose(1,0)) - 2 * Phi.mm(eVs).mm(Phi.transpose(1,0))
        ctx.save_for_backward(G, V, t)

        return y

    @staticmethod
    def backward(ctx, dzdy):
        G, V, t = ctx.saved_variables
        r,d = V.size()
        n_eigs = min(100,d)

        vone = torch.ones(r, 1, dtype=torch.float64).cuda()
        st = 1
        dzdt = 0
        Phi = V[:, st-1: n_eigs]
        Gs = G

        y = 2 * ((dzdy.transpose(1,0).mm(vone).squeeze().diag()).mm(Phi) + (dzdy.mm(vone)).squeeze().diag().mm(Phi) - dzdy.transpose(1,0).mm(Phi) - dzdy.mm(Phi)).mm(G[st-1:n_eigs, st-1: n_eigs].pow(2 * t))
        Ks = torch.zeros(r * r, n_eigs - st + 1, dtype=torch.float64).cuda()
        for p in range(n_eigs - st + 1):
            data = Phi[:,p].reshape(-1,1)
            tmp = vone.mm(data.pow(2).transpose(1,0)) +  data.pow(2).mm(vone.transpose(1,0)) - 2 * data.mm(data.transpose(1,0))
            Ks[:,p] = (2 * t[0] * Gs[p, p].pow(2 * t[0] - 1) * tmp).transpose(1,0).contiguous().view(-1)
            dzdt = dzdt + 2 * torch.log(torch.max(Gs[p, p], torch.tensor([1e-10], dtype=torch.float64).cuda())) * (Gs[p, p].pow(2 * t[0])) * tmp
        vdzdy = dzdy.reshape(1, dzdy.size(1) * dzdy.size(0))
        z = vdzdy.mm(Ks)
        dzdt = vdzdy.mm(dzdt.reshape(-1,1))
        z = z.squeeze().diag()

        #print(dzdt)

        if torch.isnan(z).sum() > 0 or torch.isnan(y).sum() > 0:
            print('nan:diff')

        #print(y[100,:20])
        #import matplotlib.pyplot as plt
        #plt.imshow(y)
        #plt.show()

        return z.diag(), y, dzdt.view(-1)


# to be updated for the formulation
class kernelMatching_function(Function):

    @staticmethod
    def forward(ctx, predict, target):
        #target = 1 - target.squeeze().float()
        target = target.double().squeeze()
        #assert predict.size(0) == target.size(0), "{0} vs {1} ".format(predict.size(0), target.size(0))
        #assert predict.size(2) == target.size(1), "{0} vs {1} ".format(predict.size(2), target.size(1))
        #n = predict.size(0)
        # target_mask = (target >= 0) * (target != self.ignore_label)
        # target = target[target_mask]
        # if not target.data.dim():
        #    return Variable(torch.zeros(1))
        # predict = predict.transpose(1, 2).transpose(2, 3).contiguous()
        # predict = predict[target_mask.view(n, h, w, 1).repeat(1, 1, 1, c)].view(-1, c)
        # loss = F.cross_entropy(predict, target, weight=weight, size_average=self.size_average)
        no_pr = torch.norm(predict, 2)
        no_gt = torch.norm(target, 2)
        loss = - (predict * target).sum() / (no_gt * no_pr)
        ctx.save_for_backward(predict, target, no_pr, no_gt)

        return loss

    @staticmethod
    def backward(ctx, dzdl):
        # target_mask = (target >= 0) * (target != self.ignore_label)
        # target = target[target_mask]
        # if not target.data.dim():
        #    return Variable(torch.zeros(1))
        # predict = predict.transpose(1, 2).transpose(2, 3).contiguous()
        # predict = predict[target_mask.view(n, h, w, 1).repeat(1, 1, 1, c)].view(-1, c)
        # loss = F.cross_entropy(predict, target, weight=weight, size_average=self.size_average)

        # grad = []
        predict, target, no_pr, no_gt = ctx.saved_variables
        gt = (target / no_gt).reshape(-1, 1)
        x = predict.reshape(-1, 1)
        grad = dzdl * (-1 / no_pr * (gt - x * (x.transpose(1, 0).mm(gt)) / no_pr.pow(2))).reshape(target.size())

        #print(no_pr)
        #print(gt.type())
        #print(grad[440,:10])
        #import matplotlib.pyplot as plt
        #plt.imshow(grad)
        #plt.show()


        if torch.isnan(grad).sum() > 0:
            print('nan')


        return grad, None


# codes for gradient checking
if __name__ == '__main__':
    # check gradient
    from torch.autograd import gradcheck
    from torch.autograd import Variable

    # check loss layer
    #'''
    input = (
        Variable(100 * torch.randn(20, 20).double(), requires_grad=True),
        Variable(100 * torch.randn(20, 20).double(), requires_grad=False),
    )
    test = gradcheck(kernelMatching_function.apply, input, eps=1e-6, atol=1e-4)
    print(test)
    #'''

    # check gradient for super-pixel_pooling layer
    # (ctx, input, segLabels, coor_idx):
    lab = torch.ones(2, 2).double().cuda()
    lab[0:1, 0:] = 2
    fea = torch.rand(1, 5, 2, 2).double().cuda()
    r = range(1, 3, 1)
    c = range(1, 3, 1)
    grid = np.meshgrid(c, r)
    grid = np.stack(grid)
    coor_idx = torch.from_numpy(grid.reshape(2, -1)).cuda()
    input = (
        Variable(fea.float().cuda(), requires_grad=True),
        Variable(lab.double().cuda(), requires_grad=False),
        Variable(coor_idx.cuda(), requires_grad=False),
    )
    test = gradcheck(SpixelsAggr_avr_function.apply, input, eps=3e-5, atol=1e-3)
    print(test)
    #out = SpixelAggr_avr_cuda.forward(out.contiguous(), fea.contiguous(), lab.contiguous(), nSeg.contiguous())
    #print('______')
    #print(fea)
    #print('______')
    #print(out)
    #print('______')
    #print(lab)


    # check diff_distance layer
    ''' FINE
    tmp = torch.rand(10,10).double()
    input = (
        Variable(torch.rand(10).double().diag().cuda(), requires_grad=True),
        Variable(tmp.mm(tmp).double().cuda(),requires_grad=True),
        Variable(torch.tensor([5]).double().cuda(), requires_grad=True),
    )
    test = gradcheck(compDiffDist_function.apply, input, eps=1e-8, atol=1e-4)
    print(test)
    '''

    # check compEigDecomp_function
    ''' ???
    tmp = torch.rand(3,3).double()
    input = (
         Variable(tmp.mm(tmp.permute(1,0)).double().cuda(),requires_grad=True),
    )
    test = gradcheck(compEigDecomp_function.apply, input, eps=1e-4, atol=1e-4)
    print(test)
    '''

    #check compNormSimiMatrix_function layer
    ''' FINE!
    tmp = torch.rand(5, 5).double()
    input = (
        Variable(tmp.mm(tmp).double().cuda(), requires_grad=True),
    )
    test = gradcheck(compNormSimiMatrix_function.apply, input, eps=1e-6, atol=1e-4)
    print(test)
    '''

    # check masking layer
    ''' FINE
    tmp = torch.rand(5, 5).double()
    input = (
        Variable(tmp.mm(tmp).double(), requires_grad=True),
        Variable(torch.rand(5,5).double() > 0, requires_grad=True),
    )
    test = gradcheck(neighMasking_function.apply, input, eps=1e-6, atol=1e-4)
    print(test)
    '''

    # check dist2SimiMatrix_function layer
    ''' FINE
    tmp = torch.rand(5, 5).double()
    input = (
        Variable(tmp.mm(tmp).double().cuda(), requires_grad=True),
        Variable(torch.rand(1).double().cuda(), requires_grad=True),
    )
    test = gradcheck(dist2SimiMatrix_function.apply, input, eps=1e-6, atol=1e-4)
    print(test)
    '''

    # check Feat2Dist_function layer
    ''' FINE
    tmp = torch.rand(5, 5).double()
    input = (
        Variable(tmp.mm(tmp).double().cuda(), requires_grad=True),
    )
    test = gradcheck(Feat2Dist_function.apply, input, eps=1e-6, atol=1e-4)
    print(test)
    '''



