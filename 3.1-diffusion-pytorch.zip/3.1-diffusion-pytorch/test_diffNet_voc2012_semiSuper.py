#### This file is to test learned diffNet on VOC-2012 dataset
import argparse

import torch
import torch.nn as nn
from torch.utils import data
import numpy as np
from torch.autograd import Variable
import torch.optim as optim
import scipy.misc
import torch.backends.cudnn as cudnn
import sys
import os
import os.path as osp
from diffMap_deeplab.model import DiffNet
from diffMap_deeplab.model import Res_Deeplab
from diffMap_deeplab import BSDataSet
from diffMap_deeplab.diffMap_layers import loss_kernelMatching
import matplotlib.pyplot as plt
import random

ModelPATH = '/home/jiansun/Projects/DiffusionMap/snapshots_diffMap/BSD_diffMap10000.pth'
ListPATH = '/home/jiansun/Dataset/VOC_dataSet/VOC2012_imgList_valid.txt'# './VOC_dataSet/VOC2012_imgList.txt'

FilePath = '/home/jiansun/Dataset/VOC_dataSet/VOC2012_Train_scribbleLabels/'
# load the learned diff-Distance net

model = DiffNet()
model.load_state_dict(torch.load(ModelPATH))
model.cuda()


# load the dataset of VOC-2012 with scribble labels
img_ids = [i_id.strip() for i_id in open(ListPATH)] #
IMG_MEAN = np.array((104.00698793,116.66876762,122.67891434), dtype=np.float32)

fig = plt.figure()
img_id = 0
for id in range(img_ids.__len__()):
    if id % 1 == 0:
        # read data
        try:
            #img_id = 53
            mat_file = scipy.io.loadmat(FilePath + img_ids[img_id] + '_tmp.mat')
            #mat_file = mat_file['a_dict']

            image = mat_file['im']
            image = np.asarray(image, np.float32)
            image = image - IMG_MEAN
            image = image.transpose((2, 0, 1))
            image = torch.from_numpy(np.asarray(image, np.float32)).cuda()
            image = image.reshape(1, image.size(0), image.size(1), image.size(2))

            seglabel = mat_file['labels'] #.value.transpose([0, 2, 1])
            neigMask = mat_file['neighMask']  #
            coor = mat_file['coor']
            lamap = mat_file['lamap']

            seglabel = torch.from_numpy(np.asarray(seglabel, np.float32)).cuda()
            neigMask = torch.from_numpy(np.asarray(neigMask, np.float32)).cuda()
            coor = torch.from_numpy(np.asarray(coor, np.float32)).cuda()

            image = Variable(image).cuda()

            # apply the learned net to VOC-2012 dataset for generating the diffused labels
            r = range(4, image.size(2)-3, 8)
            c = range(4, image.size(3)-3, 8)
            grid = np.meshgrid(c, r)
            grid = np.stack(grid)
            coor_idx = torch.from_numpy(grid).reshape(2, -1).cuda()  #

            images = Variable(image).cuda()
            seglabel = seglabel.cuda()
            neigMask = neigMask.cuda()
            inputs = (image, seglabel, neigMask, coor_idx)
            pred = model(inputs)
            #pred_output = pred
            mat_file['pred'] = pred.cpu().detach().numpy()

            # apply the learned affinity matrix for scribble label diffusion
            # save the results
            # scipy.io.savemat([img_ids[0], '.mat'], pred, appendmat=True)

            # visualize the result
            img = torch.from_numpy(mat_file['im'])
            plt.subplot(1, 3, 1)
            plt.imshow(img)

            r,c,d = img.size()

            idx_tmp = seglabel[int(r/2), int(c/2)]
            mapIdx = pred[int(idx_tmp) - 1]
            diffMap = torch.zeros(img.size(0), img.size(1))
            diffMap = mapIdx[seglabel.long() - 1]
            plt.subplot(1, 3, 2)
            plt.imshow(diffMap.data)
            #plt.show()


            #################################################################
            ## Perform diffusion by harmonic analysis
            pred[pred < 0.80] = 0
            sps0 = seglabel[(lamap > 0).nonzero()] # lamap indicates the label map
            sps = torch.unique(sps0.cpu()) - 1
            sps_u = np.setdiff1d(np.arange(0, pred.size(1)), sps.cpu())

            #D = diag(sum(W, 2))
            D = pred.sum(1).diag()

            Du = D[sps_u, :]
            Du = Du[:, sps_u]

            Wu = pred[sps_u, :]
            Wu = Wu[:,sps_u]

            Wul = pred[sps_u, :]
            Wul = Wul[:, sps.numpy()]

            labs_segs = np.zeros(pred.size(0))
            labs_segs[sps0.cpu().int().numpy() - 1] = lamap[(lamap > 0).nonzero()]
            fl = labs_segs[sps.cpu().int().numpy()]
            fl_hot = np.zeros((fl.__len__(), 21))
            fl_hot[np.arange(0, fl.__len__()), fl.astype(int) - 1] = 1
            fl_hot = torch.from_numpy(fl_hot)
            tmp = torch.from_numpy(np.linalg.pinv((Du - Wu).data))
            re = tmp.mm(Wul.cpu()).mm(fl_hot)

            lb_et = np.zeros((pred.size(0), 21))
            lb_et[sps.numpy().astype(int)] = fl_hot
            lb_et[sps_u] = re.data

            id = lb_et.argmax(1)
            v = lb_et.max(1)
            id[(v<0.15).nonzero()] = 0

            segResult = id[seglabel.cpu().numpy().astype(int) - 1]
            mat_file['segResult'] = segResult

            #[a, lb] = max(lb_et, [], 2);
            #lb(find(a < 0.05)) = 1;


            #fl_hot[] = 1;
            #fl_hot(sub2ind(size(fl_hot), [1: length(fl)]', fl)) = 1;
            #fl[np.arange(0, fl.), fl]

            #fl = labs_segs(sps);
            #fl_hot = zeros(size(fl, 1), 21);
            #fl_hot(sub2ind(size(fl_hot), [1: length(fl)]', fl)) = 1;


            #except:
            #    print('invalid file')


            #if img_id % 20 == 0:
            #    plt.close('all')

            segResult = torch.from_numpy(segResult)
            #plt.subplot(1,3,3)
            #plt.imshow(segResult)
            #plt.show()

            #mat_file['seg_diff'] = segResult.cpu()
            save_segResult=np.asarray(segResult,np.float32)
            mat_name=FilePath + img_ids[img_id] + '.mat' #'_tmp.mat' #
            #mat_name = FilePath + '_tmp.mat'
            #with open(mat_name, 'ab') as f:
            #    scipy.io.savemat(f, {'seg_diff2': save_segResult})

            a_dict = {'pred':pred.cpu().detach().numpy(), 'segResult': save_segResult,'im': mat_file['im'], 'labels':mat_file['labels'], 'neighMask':mat_file['neighMask'], 'coor':coor_idx.cpu().detach().numpy(), 'lamap':mat_file['lamap']}
            scipy.io.savemat(mat_name, a_dict) #{'a_dict': a_dict}

            print(img_id)

        except:
            print('invalid file')


    img_id = img_id + 1